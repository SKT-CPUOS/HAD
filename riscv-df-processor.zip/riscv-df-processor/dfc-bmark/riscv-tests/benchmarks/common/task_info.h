
 /// @file    task_info.h
 /// @author  hessen(dhxsy1994@gmail.com)
 /// @date    2021-03-28 21:57:40
 ///
 
extern int task_argv[];
extern int task_state[];
extern int size;


