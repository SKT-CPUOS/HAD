typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;

typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned int   uint32;
