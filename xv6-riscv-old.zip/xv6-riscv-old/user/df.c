#include "../kernel/types.h"
#include "../kernel/fcntl.h"
#include "../kernel/riscv.h"

#define innerreps 20
int delaylength  = 0;
int thread_num  = 0;


void delay(int delaylength)
{
	int i;
	int a = 0.;
	for (int i = 0; i < delaylength; i++)
		a += i;
	if (a < 0)
		printf("%d \n", a);
	
}

void refer() {
	int j;
	for (j = 0; j < innerreps; j++) {
		delay(delaylength);
	}
}


void add1(uint32* arg) 
{ 
	arg[3] = arg[0] + arg[1]; 
	listen_table(&arg[3]);
	exit_thread();
}
void add2(uint32* arg) 
{ 
	arg[4] = arg[1] + arg[2]; 
	listen_table(&arg[4]);
	exit_thread();
}
void add3(uint32* arg) 
{ 
	arg[5] = arg[3] + arg[4]; 
	exit_thread();
}

void dataflowTest(uint32 * addr)
{
	// printf("trigger !\n");
	delay(2);
	listen_table(addr);
	exit_thread();
}

void dataflowTestMain()
{
	uint32 arg[] = { (uint32)1, (uint32)2, (uint32)3, (uint32)4, (uint32)5 , (uint32)6,(uint32)7,(uint32)8,(uint32)9,(uint32)10,
	(uint32)11, (uint32)12, (uint32)13, (uint32)14, (uint32)15 , (uint32)16,(uint32)17,(uint32)18,(uint32)19,(uint32)20,
	(uint32)21, (uint32)22, (uint32)23, (uint32)24, (uint32)25 , (uint32)26,(uint32)27,(uint32)28,(uint32)29,(uint32)30,
	(uint32)31,(uint32)32,(uint32)33,(uint32)34};  
	// uint32 arg[33];
	printf("start\n");
	for (int i = 0; i < thread_num; i++)
	{
		void* stack1 = malloc(PGSIZE);
		int pid1 = clone(dataflowTest, &arg[i+1], stack1, 0);
		write_table(&arg[i],pid1);
	}
	printf("table Write Complete\n");
	listen_table(&arg[0]);
	for (int i = 0; i < thread_num; i++)
	{
		join();
	}
	
	printf("done\n");
}

void referTest(uint32 * addr)
{
	printf("trigger !\n");
	delay(2);
	exit_thread();
}

void referTestMain()
{
	uint32 arg[] = { (uint32)1, (uint32)2, (uint32)3, (uint32)4, (uint32)5 , (uint32)6,(uint32)7,(uint32)8,(uint32)9,(uint32)10,
	(uint32)11, (uint32)12, (uint32)13, (uint32)14, (uint32)15 , (uint32)16,(uint32)17,(uint32)18,(uint32)19,(uint32)20,
	(uint32)21, (uint32)22, (uint32)23, (uint32)24, (uint32)25 , (uint32)26,(uint32)27,(uint32)28,(uint32)29,(uint32)30,
	(uint32)31,(uint32)32,(uint32)33,(uint32)34}; 
	// uint32 arg[33];
	printf("start\n");
	for (int i = 0; i < 32; i++)
	{
		void* stack1 = malloc(PGSIZE);
		clone(referTest, &arg[i+1], stack1, 1);
	}
	for (int i = 0; i < 32; i++)
	{
		join();
	}
	
	printf("done\n");
}
int id = 0;
int run = 0;

void lockTest(uint32 * addr)
{
	int go = 0;
	while(go == 0)
	{
		sem_p(run);
		go = run;
		sem_v(run);
	}
	
	sem_p(id);
	// printf("trigger !\n");
	delay(2);
	
	sem_v(id);

	exit_thread();
}

void lockTestMain()
{
	uint32 arg[] = { (uint32)1, (uint32)2, (uint32)3, (uint32)4, (uint32)5 , (uint32)6,(uint32)7,(uint32)8,(uint32)9,(uint32)10,
	(uint32)11, (uint32)12, (uint32)13, (uint32)14, (uint32)15 , (uint32)16,(uint32)17,(uint32)18,(uint32)19,(uint32)20,
	(uint32)21, (uint32)22, (uint32)23, (uint32)24, (uint32)25 , (uint32)26,(uint32)27,(uint32)28,(uint32)29,(uint32)30,
	(uint32)31, (uint32)32, (uint32)33, (uint32)34, (uint32)35 , (uint32)36,(uint32)37,(uint32)38,(uint32)39,(uint32)40,
	(uint32)41, (uint32)42, (uint32)43, (uint32)44, (uint32)45 , (uint32)46,(uint32)47,(uint32)48,(uint32)49,(uint32)50,
	(uint32)51, (uint32)52, (uint32)53, (uint32)54, (uint32)55 , (uint32)56,(uint32)57,(uint32)58,(uint32)59,(uint32)60,
	(uint32)61, (uint32)62, (uint32)63, (uint32)64, (uint32)65 , (uint32)66}; 
	// uint32 arg[33];
	printf("start\n");
	id=sem_create(1);
	run=sem_create(0);
	for (int i = 0; i < thread_num; i++)
	{
		void* stack1 = malloc(PGSIZE);
		clone(lockTest, &arg[i+1], stack1, 1);
		// printf("create proc \n");
	}
	printf("Create Complete\n");
	// sem_p(run);
	run = 1;
	sem_v(run);
	for (int i = 0; i < thread_num; i++)
	{
		join();
	}
	printf("done\n");
	sem_free(id);
	sem_free(run);
}

int main(int argc, char** argv)
{
	// printf("reference computing start! \n");
	// referTestMain();
	printf("enter process num:\n");
	char buf[3];
	gets(buf,3);
	thread_num = (buf[0] - '0')*10 + (buf[1] - '0');
	printf("data flow computing start! \n");
	dataflowTestMain();
	printf("lock computing start! \n");
	lockTestMain();
	// uint32 arg[] = { (uint32)1, (uint32)2, (uint32)3, (uint32)0, (uint32)0 , (uint32)0}; 
	// // void* stack1 = malloc(PGSIZE);
	// // void* stack2 = malloc(PGSIZE);
	// // void* stack3 = malloc(PGSIZE);

	// // int pid1 = clone(add1, arg, stack1, 0);
	// // int pid2 = clone(add2, arg, stack2, 0);
	// // int pid3 = clone(add3, arg, stack3, 0);

	// // write_table(&arg[0], pid1);
	// // write_table(&arg[1], pid1);
	// // write_table(&arg[1], pid2);
	// // write_table(&arg[2], pid2);
	// // write_table(&arg[3], pid3);
	// // write_table(&arg[4], pid3);
	
	// // listen_table(&arg[0]);
	// // listen_table(&arg[1]);
	// // listen_table(&arg[2]);
	// // join();
	// // join();

	
	// // printf("%p %p\n", arg[3], arg[4]);
	// // join();
	// delaylength = 32;
	// refer();

	// printf("done \n");
	// printf("%p %p %p \n", arg[3], arg[4], arg[5]);
	exit(0);
}
