#include "../kernel/types.h"
#include "../kernel/fcntl.h"
#include "../kernel/riscv.h"


#define PI 3141
#define N 16
#define K 4 // 2^K = N

int abs(int x){
    if(x>=0){
        x=x;
    }else{
        x=-x;
    }
    return x;
}

int pow(int x,int k){
	int sum=1;
	int i;
    while (k != 0)
    {
		sum*=x;
		--k;
	}
	return sum;
}

int sin(int x)
{
	//****************************
	int counter=0;
	if(x<0){
		counter=1;
	}else{
		counter =0;
	}
	x=abs(x);
	//****************************
    int t,q=1;
    int term,factorial=1000,sum2,sxm,sum1=0;
 
    sum2=x;
    for(t=2;;t++)
    {
        factorial=factorial*t;
        if(t%2!=0)
        {
            sum1=sum2;
            q=q*(-1);
            sxm=abs(pow(x,t));
            term=sxm/factorial;
            sum2=q*term+sum2;
        }
        if(abs(sum2-sum1)<=10)
        break;
    }
        
    if(counter==1){
        sum2=-sum2;
        return sum2; 
    }
    else{
        return sum2;
    }   
}

int cos(int x)
{
	//********************
	x=abs(x);
	//********************
    int t,q=1000;
    int term,factorial=1000,sum2=1000,sxm,sum1=0;
    for(t=2;;t++)
    {
        factorial=factorial*t;
        if(t%2==0)
        {
            sum1=sum2;
            q=q*(-1);
            sxm=abs(pow(x,t));
            term=sxm/factorial;
            sum2=q*term+sum2;
        }
        if(abs(sum2-sum1)<=10)
            break;
    }
    return sum2; 
}


int sqrt(int x) 
{
	if(x <= 0)	return 0;
	int res, lastres;
	res = x;	//初始值，可以为任意非0的值
	
	do{
		lastres = res;
		res = (res + x/res)/2;
	}
	while(abs(lastres-res) > 1);

	return res;
}

void fftdiv(int * arg)
{   
    int it = arg[0],m = arg[1],nv = arg[2];
    int p,q,s,poddr,poddi;
    int *pr,*pi,*fr,*fi;
    pr = (int *)shmgetat(1,1);
    pi = (int *)shmgetat(2,1);
    fr = (int *)shmgetat(3,1);
    fi = (int *)shmgetat(4,1);

    printf("create one\n"); 
    printf("%p %p %p\n",it,m,nv); 
    for (int j=0; j<=(nv/2)-1; j++)
    { 
        p=pr[m*j]*fr[it+j+nv/2];
        q=pi[m*j]*fi[it+j+nv/2];
        s=pr[m*j]+pi[m*j];
        s=s*(fr[it+j+nv/2]+fi[it+j+nv/2]);
        poddr=p-q; 
        poddi=s-p-q;
        fr[it+j+nv/2]=fr[it+j]-poddr;
        fi[it+j+nv/2]=fi[it+j]-poddi;
        fr[it+j]=fr[it+j]+poddr;
        fi[it+j]=fi[it+j]+poddi;
    }
	exit_thread();
    // return;
}



void kfft()
{ 
    int it,m,is,i,j,nv,l0;
    int p,q,s,vr,vi,poddr,poddi;
    int *pr,*pi,*fr,*fi;
    pr = (int *)shmgetat(1,1);
    pi = (int *)shmgetat(2,1);
    fr = (int *)shmgetat(3,1);
    fi = (int *)shmgetat(4,1);

    for (it=0; it<=N-1; it++)  //将pr[0]和pi[0]循环赋值给fr[]和fi[]
    { 
        m=it; 
        is=0;
        for(i=0; i<=K-1; i++)
        { 
            j=m/2; 
            is=2*is+(m-2*j); 
            m=j;
        }
        fr[it]=pr[is]; 
        fi[it]=pi[is];
    }
    pr[0]=1; 
    pi[0]=0;
    // p=6.283185306/(1.0*N);
    p=6283/(1*N);
    pr[1]=cos(p); //将w=e^-j2pi/n用欧拉公式表示
    pi[1]=-sin(p);

    for (i=2; i<=N-1; i++)  //计算pr[]
    { 
        p=pr[i-1]*pr[1]; 
        q=pi[i-1]*pi[1];
        s=(pr[i-1]+pi[i-1])*(pr[1]+pi[1]);
        pr[i]=p-q; pi[i]=s-p-q;
    }
    for (it=0; it<=N-2; it=it+2)  
    { 
        vr=fr[it]; 
        vi=fi[it];
        fr[it]=vr+fr[it+1]; 
        fi[it]=vi+fi[it+1];
        fr[it+1]=vr-fr[it+1]; 
        fi[it+1]=vi-fi[it+1];
    }
    m=N/2; 
    nv=2;
    int id,run;
    int thread = 0;
    id=sem_create(1);
	run=sem_create(0);
    for (l0=K-2; l0>=0; l0--) //蝴蝶操作
    { 
        m=m/2; 
        nv=2*nv;
        for (it=0; it<=(m-1)*nv; it=it+nv)
        {
            // void * arg = {it,m,nv};
            int arg[3];
            arg[0] = it;
            arg[1] = m;
            arg[2] = nv;
            // fftdiv(arg);
            void* stack1 = malloc(PGSIZE);
            int pid1 = clone(fftdiv, arg, stack1, 1);
            thread++;
        }
    }

    printf("create thread done\n");

    for (int i = thread;i > 0;i--)
        join();

    for (i=0; i<=N-1; i++)
    { 
        pr[i]=sqrt(fr[i]*fr[i]+fi[i]*fi[i]);  //幅值计算
    }
    return;
}

void add1(uint32* arg) 
{ 
	arg[3] = arg[0] + arg[1]; 
	listen_table(&arg[3]);
	exit_thread();
}
void add2(uint32* arg) 
{ 
	arg[4] = arg[1] * arg[2]; 
	listen_table(&arg[4]);
	exit_thread();
}
void add3(uint32* arg) 
{ 
	arg[5] = arg[3] + arg[4]; 
	exit_thread();
}


int main(int argc, char** argv)
{
	// printf("reference computing start! \N");
	// referTestMain();

	printf("data flow computing start! \n");

	// uint32 arg[] = { (uint32)1, (uint32)2, (uint32)3, (uint32)0, (uint32)0 , (uint32)0}; 
	// void* stack1 = malloc(PGSIZE);
	// void* stack2 = malloc(PGSIZE);
	// void* stack3 = malloc(PGSIZE);

	// int pid1 = clone(add1, arg, stack1, 0);
	// int pid2 = clone(add2, arg, stack2, 0);
	// int pid3 = clone(add3, arg, stack3, 0);

	// write_table(&arg[0], pid1);
	// write_table(&arg[1], pid1);
	// write_table(&arg[1], pid2);
	// write_table(&arg[2], pid2);
	// write_table(&arg[3], pid3);
	// write_table(&arg[4], pid3);
	
	// listen_table(&arg[0]);
	// listen_table(&arg[1]);
	// listen_table(&arg[2]);
	// join();
	// join();

	
	// printf("%p %p\N", arg[3], arg[4]);
	// join();

	// printf("done \N");
	// printf("%p %p %p \N", arg[3], arg[4], arg[5]);
    // int pr[N],pi[N],fr[N],fi[N],t[N];
    int t[N];
    int *pr,*pi,*fr,*fi;
    pr = (int *)shmgetat(1,1);
    pi = (int *)shmgetat(2,1);
    fr = (int *)shmgetat(3,1);
    fi = (int *)shmgetat(4,1);
    printf("Generating input signal\n");
    int i,j;
    // int pr[N],pi[N],fr[N],fi[N],t[N];
    for (i=0; i<N; i++)  //生成输入信号
    { 
		t[i] = i;
		pr[i]=100+50*cos(2*PI*t[i]); pi[i]=0;
        fr[i] = 0;fi[i] = 0;
	}
    printf("Starting FFT\n");
		
    kfft();  //调用FFT函数
	// for (i=0; i<N; i++)
    // { 
    //     printf("%p\t%p\N",i,pr[i]); //输出结果
    // }

    printf("done \n");

    // int pid = fork();
    // if(pid == 0){
    // sleep(100);
    // int *shm1;
    // shm1 = (int *)shmgetat(1,3);//key 为 1，大小为 3 页的共享内存
    // shm1[0] = 0;
    // printf("child process pid:%p shm is %p refcount of 1 is:%p\n", getpid(),shm1[0], shmrefcount(1));
    // shm1[0] = 123;
    // printf("child process pid:%p write %p into the shm\n", getpid(), shm1[0]);
    // } else if (pid > 0) {
    // char *shm2;
    // shm2 = (char*)shmgetat(1,3);
    // printf("parent process pid:%p before wait() shm is %p refcount of 1 is:%p\n",getpid(), shm2[0], shmrefcount(1));
    // shm2[0] = 456;
    // printf("parent process pid:%p write %p into the shm\n", getpid(), shm2[0]);
    // wait(0);
    // printf("parent process pid:%p after wait() shm is %p refcount of 1 is:%p\n",getpid(),shm2[0], shmrefcount(1));
    // }

	exit(0);
}