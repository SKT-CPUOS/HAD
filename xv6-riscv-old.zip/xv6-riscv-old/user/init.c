// init: The initial user-level program

#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "../kernel/fcntl.h"
#include "user.h"

//char *argv[] = { "ls", 0 }; //ls
//char *argv[] = { "cat", "README", 0 }; //cat
//char *argv[] = { "echo", "README", "test", 0 }; //echo
//char *argv[] = { 0 }; //forktest yield
//char *argv[] = { "wc", "ls", "README", 0 }; //wc
//char *argv[] = { "stressfs", 0 }; //stressfs
//char *argv[] = { "usertests", 0 }; //usertests
char *argv[] = { "sh", 0 };

int
main(void)
{
  int pid, wpid;

  if(open("console", O_RDWR) < 0){
    mknod("console", 1, 1);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  dup(0);  // stderr

  // int df_pid = fork();
  // if (df_pid <  0) { printf("fork failed\n"); }
  // else if (df_pid == 0) { exec("df", argv); }

  for(;;){
    printf("init: starting sh\n");
    pid = fork();
    if(pid < 0){
      printf("init: fork failed\n");
      exit(1);
    }
    if(pid == 0){
      //exec("cat", argv);
      //exec("echo", argv);
      //exec("forktest", argv);
      //exec("wc", argv);
      //exec("stressfs", argv);
	  //exec("yield", argv);
      //exec("usertests", argv);
      //exec("df", argv);
      exec("sh", argv);
      printf("init: exec sh failed\n");
      exit(1);
    }
    while((wpid=wait(0)) >= 0 && wpid != pid){
      //printf("zombie!\n");
    }
  }
}
