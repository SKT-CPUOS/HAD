#include "../kernel/types.h"
#include "user.h"


int main(int argc, char *argv[])
{
	int pid = fork();
	if (pid < 0) {
		fprintf(2, "fork error!\n");
	}
	if (0 == pid) {
		while (1) printf("%p child process\n", getpid());
	}
	else {
		while (1) printf("%p parent process\n", getpid());
	}
}
