#include "../kernel/types.h"
#include "../kernel/fcntl.h"
#include "../kernel/riscv.h"
#include "user.h"

int global = 1;

int f(int x)
{
	if (1 == x) return 1;
	if (2 == x) return 1;
	return f(x - 1) + f(x - 2);
}

int add(int x, int y) { return x + y; }

void thread_main(uint32* arg)
{
	printf("thread_main\n");
	global = f(15);
	printf("global = %p\n", global);
	printf("add = %p\n", add(arg[1], arg[2]));
	exit_thread();
}

int main(int argc, char** argv)
{
	uint32 arg[] = { (uint32)1, (uint32)2, (uint32)3, (uint32)4, (uint32)5, (uint32)6, (uint32)7, (uint32)8 };
	void* stack1 = malloc(PGSIZE);
	void* stack2 = malloc(PGSIZE);
	void* stack3 = malloc(PGSIZE);
    memset(stack1, 0, PGSIZE);
    memset(stack2, 0, PGSIZE);
    memset(stack3, 0, PGSIZE);
	int pid1 = clone(thread_main, arg, stack1, 1);
	int pid2 = clone(thread_main, arg, stack2, 1);
	int pid3 = clone(thread_main, arg, stack3, 1);
	join();
	join();
	join();
	free(stack1);
	free(stack2);
	free(stack3);
	printf("thread id = %p\n", pid1);
	printf("thread id = %p\n", pid2);
	printf("thread id = %p\n", pid3);
	printf("global = %p\n", global);
	exit(0);
}
