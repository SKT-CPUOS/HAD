#define MSTATUS_PRV1  (3L << 4)
#define MSTATUS_MIE1  (1L << 3)       // machine-mode interrupt enable

// which hart (core) is this?
static inline 
uint32 r_mhartid()
{
  uint32 x;
  asm volatile("csrr %0, mhartid" : "=r" (x) );
  return x;
}

static inline 
uint32 r_ra()
{
  uint32 x;
  asm volatile("mv %0, ra" : "=r" (x) );
  return x;
}

static inline 
void w_a0(uint32 x)
{
  asm volatile("mv a0, %0" : : "r" (x));
}

static inline 
uint32 r_a0()
{
  uint32 x;
  asm volatile("mv %0, a0" : "=r" (x) );
  return x;
}

static inline 
void w_a1(uint32 x)
{
  asm volatile("mv a1, %0" : : "r" (x));
}

static inline 
uint32 r_a1()
{
  uint32 x;
  asm volatile("mv %0, a1" : "=r" (x) );
  return x;
}

static inline 
uint32 r_s0()
{
  uint32 x;
  asm volatile("mv %0, s0" : "=r" (x) );
  return x;
}

static inline 
uint32 r_tp()
{
  uint32 x;
  asm volatile("mv %0, tp" : "=r" (x) );
  return x;
}

static inline 
void w_tp(uint32 x)
{
   asm volatile("mv tp, %0" : : "r" (x));
}

static inline
void w_mepc(uint32 x)
{
	asm volatile("csrw mepc, %0" : : "r" (x));		
}

static inline
uint32 r_mepc()
{
	uint32 x;
	asm volatile("csrr %0, mepc" : "=r" (x) );
	return x;
}

static inline
void w_mstatus(uint32 x)
{
	asm volatile("csrw mstatus, %0" : : "r" (x));
}

static inline
uint32 r_mstatus()
{
	uint32 x;
	asm volatile("csrr %0, mstatus" : "=r" (x) );
	return x;
}

static inline
uint32 r_mcause(void)
{
	uint32 x;
	asm volatile("csrr %0, mcause" : "=r" (x) );
	return x;
}

static inline
void w_mtvec(uint32 x)
{	
	asm volatile("csrw mtvec, %0" : : "r" (x));
}

static inline
uint32 r_mtvec()
{
	uint32 x;
	asm volatile("csrr %0, mtvec" : "=r" (x) );
	return x;	
}

static inline
uint32 r_mtval()
{
	uint32 x;
	asm volatile("csrr %0, mbadaddr" : "=r" (x) );
	return x;
}

static inline 
uint32 r_sp()
{
  uint32 x;
  asm volatile("mv %0, sp" : "=r" (x) );
  return x;
}

static inline
uint32 r_dfcpid()
{
	uint32 x;
	asm volatile("csrr %0, 0x800" : "=r" (x) );
	return x;	
}

// use riscv's sv32 page table scheme.
#define SATP_SV32 (2L << 30)
#define MAKE_SATP(pagetable) (SATP_SV32 | (((uint32)pagetable) >> 12))
static inline
void w_satp(uint32 x)
{
	asm volatile("csrw sptbr, %0" : : "r" (x));
}

static inline
uint32 r_satp()
{
	uint32 x;
	asm volatile("csrr %0, sptbr" : "=r" (x) );
	return x;
}

#define MSTATUS_IE  (1L << 0)
#define MIE_MTIE    (1L << 7)
#define MIP_MTIP    (1L << 7)

static inline
uint32 r_mie()
{
    uint32 x;
    asm volatile("csrr %0, mie" : "=r" (x) );
    return x;
}

static inline
void w_mie(uint32 x)
{
	asm volatile("csrw mie, %0" : : "r" (x));
}

static inline
void w_mtimecmp(uint32 x)
{
	asm volatile("csrw mtimecmp, %0" : : "r" (x));
}

static inline
uint32 r_mtime()
{
    uint32 x;
    asm volatile("csrr %0, mtime" : "=r" (x) );
    return x;
}


static inline void
intr_on()
{
	w_mstatus(r_mstatus() | MSTATUS_IE);
}

static inline void
intr_off()
{
	w_mstatus(r_mstatus() & ~MSTATUS_IE);
}

static inline int
intr_get()
{
	uint32 x = r_mstatus();
	return (x & MSTATUS_IE) != 0;
}

#define PGSIZE 		4096 	// bytes per page
#define PGSHIFT		  12 	// bits of offset within a page

#define PGROUNDUP(sz)  (((sz)+PGSIZE-1) & ~(PGSIZE-1))
#define PGROUNDDOWN(a) (((a)) & ~(PGSIZE-1))

#define PTE_V (1L << 0)
#define PTE_R (1L << 1)
#define PTE_W (1L << 2)
#define PTE_X (1L << 3)
#define PTE_U (1L << 4) // 1 -> user can access

#define PA2PTE(pa) ((((uint32)pa) >> 12) << 10)
#define PTE2PA(pte) (((pte) >> 10) << 12)
#define PTE_FLAGS(pte) ((pte) & 0x3FF)

#define PXMASK			0x3FF // 10bits
#define PXSHIFT(level)  (PGSHIFT+(10*(level)))
#define PX(level, va) ((((uint32) (va)) >> PXSHIFT(level)) & PXMASK)
