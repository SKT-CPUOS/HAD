#include "types.h"
#include "param.h"
#include "riscv.h"
#include "memlayout.h"
#include "defs.h"

void main(void)
{
	extern char end[];
	intdump((int)end);
	if (0 == cpuid()) {
		consoleinit();
		printfinit();
		printf("riscv32-mini-xv6 kernel is booting\n");
		kinit();  		     printf("kinit() ok\n");
		kvminit();		     printf("kvminit() ok\n");
		kvminithart();       printf("kvminithart() ok\n");
		printf("satp:  %p\n", r_satp());
		procinit();		     printf("procinit() ok\n");
		trapinit();			 printf("trapinit() ok\n");
		trapinithart();      printf("trapinithart() ok\n");
		printf("mtvec: %p\n", r_mtvec()); 
		binit();		     printf("binit() ok\n");
	    iinit();		     printf("iinit() ok\n");
		fileinit();		     printf("fileinit() ok\n");	
		virtio_disk_init();  printf("virtio_disk_init() ok\n");
		seminit(); 			 printf("seminit() ok\n");
		sharememinit();		 printf("sharememinit() ok\n");
		userinit();		     printf("userinit() ok\n");
		timerinit();         printf("timerinit() ok\n");
		__sync_synchronize();
		intdump((int)end);
		//test_cache((int*)end, 100000);
		//check_memory((int*)end, 10000);
		scheduler();
	}
}
