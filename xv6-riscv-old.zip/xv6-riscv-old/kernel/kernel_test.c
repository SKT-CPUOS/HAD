#include "types.h"
#include "param.h"
#include "defs.h"
#include "riscv.h"
#include "spinlock.h"
#include "memlayout.h"
#include "proc.h"

void hexdump(char x)
{    
     static const char hex[] = "0123456789abcdef";
     uart_puts("0x"); 
     char high = (x & 0xf0) >> 4;
     char low  = (x & 0x0f);
     uart_putchar(hex[high]);
     uart_putchar(hex[low]);
}

void intdump(int val)
{
	static const char hex[] = "0123456789abcdef";
	char *p = (char*)&val;
	uart_puts("0x");
	for (int k = 3; k >= 0; --k) {
		char x = *(p + k);
		char high = (x & 0xf0) >> 4;
		char low  = (x & 0x0f);
		uart_putchar(hex[high]);
		uart_putchar(hex[low]);	 	
	}
	uart_puts("\n");
}

void check_memory(uchar* pa, int size)
{   
    for (int k = 1; k <= size; ++k) {
        char ch = *pa;
        hexdump(ch);
        int x = k & (~0xfffffff8);
        if (x) uart_putchar(' ');
        else uart_putchar('\n');
        ++pa;
    }
}

void kalloc_test(void)
{   
    extern char end[];
    uart_puts("test kalloc begin\n");
    for (int k = 0; k < 10; ++k) {
        char* p = kalloc();
        if (0 == k && p == (char*)0x10003000) uart_puts("equal");
        if (null == p) {
            uart_puts("kalloc out\n");
            break;
        }
        uart_getchar(); 
        check_memory(p, PGSIZE);
    }
    char* st = (char*)PGROUNDUP((uint32)end);
    char* ed = (char*)((uint32)PHYSTOP);
    uart_puts("test kfree\n");
    for (; st + PGSIZE <= ed; st += PGSIZE) {
        kfree(st); 
        uart_puts("getchar\n");
        uart_getchar();
        check_memory(st, PGSIZE);
    }
    for (int k = 0; k < 10; ++k) {
        char* p = kalloc();
        if (0 == k && p == (char*)0x10003000) uart_puts("equal");
        if (null == p) {
            uart_puts("kalloc out\n");
            break;
        }
        uart_getchar(); 
        check_memory(p, PGSIZE);
    }
    uart_puts("end kalloc end\n");
}

void kalloc_max_test(void)
{
    uart_puts("test kalloc max begin\n");
    uart_getchar();
    int cnt = 0;
    for (int k = 0; k < 10000000; ++k) {
        char* p = kalloc();
		intdump((int)p);
        if (null == p) { uart_puts("kalloc out\n"); break; }
        ++cnt;
    }
	intdump(cnt);
    uart_puts("\ntest kalloc max end\n");
}

void kvminit_test(void)
{
	extern pagetable_t kernel_pagetable;
	uint32 _start = KBASE;
	uint32 _end	  = PGROUNDDOWN(TESTSTOP - 1);
	uart_puts("pgdir: "); intdump((int)kernel_pagetable);
	for (; _start <= _end; _start += PGSIZE) {
		uart_puts("va: "); intdump((int)_start);
		pde_t *pde = &kernel_pagetable[PX(1, _start)];
		uart_puts("pde base: "); intdump((int)pde);
		uart_puts("pde val:  "); intdump((int)*pde);
		pte_t *pgtab = (pte_t*)PTE2PA(*pde);
		uart_puts("pte base: "); intdump((int)pgtab);
		uart_puts("pte addr: "); intdump((int)&pgtab[PX(0, _start)]);
		uart_puts("pte val:  "); intdump((int)pgtab[PX(0, _start)]);
		int tp = ((int)pgtab[PX(0, _start)]);
		int pte_val = (tp >> 10) << 12;
		int offset  = _start & 0xfffff000;
		uart_puts("pa: "); intdump(pte_val | offset);
	}	
}

uchar* uvminit_test(pagetable_t pagetable, uint32 size)
{
	uchar *res = null;
	uint32 _start = 0;
	uint32 _end	  = PGROUNDDOWN(size - 1);
	uart_puts("pgdir: "); intdump((int)pagetable);
	for (; _start <= _end; _start += PGSIZE) {
		uart_puts("va: "); intdump((int)_start);
		pde_t *pde = &pagetable[PX(1, _start)];
		uart_puts("pde base: "); intdump((int)pde);
		uart_puts("pde val:  "); intdump((int)*pde);
		pte_t *pgtab = (pte_t*)PTE2PA(*pde);
		uart_puts("pte base: "); intdump((int)pgtab);
		uart_puts("pte addr: "); intdump((int)&pgtab[PX(0, _start)]);
		uart_puts("pte val:  "); intdump((int)pgtab[PX(0, _start)]);
		int tp = ((int)pgtab[PX(0, _start)]);
		int pte_val = (tp >> 10) << 12;
		int offset  = _start & 0xfffff000;
		uart_puts("pa:  "); intdump(pte_val | offset);
		res = (uchar*)(pte_val | offset);
	}	
	return res;
}

void vm_test(void)
{
	int *p = (int*)0x00001000;
    intdump((int)p);
    *p = 5;
    check_memory((uchar*)p, 4);
    intdump(*p);
    printf("This message should not appear\n");
}

void read_satp(void)
{
	printf("read_satp()\n");
	uint32 x = r_satp();
	intdump(x);
}

void test_cache(int* start, int sz)
{
	uart_puts("test_cache begin\n");
	for (int k = 0; k < sz; ++k) start[k] = k;
	for (int k = 0; k < sz; ++k) {
		if (start[k] != k) uart_puts("error!\n");	
	}
	uart_puts("test_cache end\n");
}
