#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"


uint32
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1; 
  exit(n);
  return 0;  // not reached
}

uint32
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1; 
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1; 
  return addr;
}

uint32
sys_fork(void)
{ 
  return fork();
}

uint32
sys_wait(void)
{
  uint32 p;
  if(argaddr(0, &p) < 0)
    return -1;
  return wait(p);
}


uint32
sys_getpid(void)
{ 
  return myproc()->pid;
}

uint32
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

uint32
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1; 
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){ 
    if(myproc()->killed){
      release(&tickslock);
      return -1; 
    }   
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint32
sys_clone(void)
{
  uint32 f;
  uint32 arg;
  uint32 stack;
  uint32 state;

  if (argaddr(0, &f) < 0)     return -1;
  if (argaddr(1, &arg) < 0)   return -1;
  if (argaddr(2, &stack) < 0) return -1;
  if (argint(3, &state) < 0)  return -1;
  return clone((void(*)(void*))f, (uint32*)arg, (void*)stack, (int)state);
}

uint32
sys_join(void)
{
  return join();
}


uint32
sys_exit_thread(void)
{
  exit_thread();
  return 0;
}

uint32
sys_shmgetat (void)
{
  int key, num;
  if(argint(0, &key) < 0 || argint(1, &num) < 0)
    return -1;
  return (uint32)shmgetat(key,num);
}
int
sys_shmrefcount(void)
{
int key;
if(argint(0,&key)<0)
return -1;
return shmrefcount(key);
}



