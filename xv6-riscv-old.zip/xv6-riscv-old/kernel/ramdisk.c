//
// ramdisk that uses the disk image loaded by qemu -initrd fs.img
//

#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "buf.h"

extern char _binary_fs_img_start[];
extern char _binary_fs_img_size[];

static char *ramdisk;
static int disksize;

void
virtio_disk_init(void)
{
	ramdisk  = _binary_fs_img_start;
	disksize = (uint32)_binary_fs_img_size / BSIZE; 
}

void virtio_disk_intr(void)
{
}

// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
virtio_disk_rw(struct buf *b, int write_or_read)
{
  if(!holdingsleep(&b->lock)) panic("ramdiskrw: buf not locked");
  if((write_or_read != 1) && (write_or_read != 0)) panic("ramdiskrw: nothing to do");
  if(b->blockno >= FSSIZE) panic("ramdiskrw: blockno too big");

  uint32 diskaddr = b->blockno * BSIZE;
  char *addr = ramdisk + diskaddr;

  if(1 == write_or_read){
    // write
    memmove(addr, b->data, BSIZE);
  } 
  else {
    // read
    memmove(b->data, addr, BSIZE);
  }
}
