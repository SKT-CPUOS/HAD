// uart
#define READ_VALID      ((volatile unsigned int*) 0x10000000)
#define READ_DATA_ADDR  ((volatile unsigned char*)0x10000004)
#define WRITE_VALID     ((volatile unsigned int*) 0x10000008)
#define WRITE_DATA_ADDR ((volatile unsigned char*)0x1000000c)

#define KBASE  		0x80000000L
#define PHYSTOP 	(KBASE + 128 * 1024 * 1024)
//#define PHYSTOP 	(KBASE + 64 * 1024 * 1024)
#define TESTSTOP 	(KBASE + 128 * 1024 * 1024)
#define MAXVA		0xFFFFFFFFL
#define TRAMPOLINE (MAXVA - PGSIZE + 1)
#define TRAPFRAME (TRAMPOLINE - PGSIZE)
#define KSTACK(p) (TRAMPOLINE - ((p)+1)* 2*PGSIZE)
//#define KSTACK(p) (TRAMPOLINE - (((p)+1) << 13)) 
