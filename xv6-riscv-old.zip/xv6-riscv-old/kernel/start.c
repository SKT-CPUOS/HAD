#include "types.h"
#include "param.h"
#include "riscv.h"
#include "defs.h"

void main(void);

__attribute__ ((aligned (16))) char kstack[4096 * NCPU];

// entry.S jumps here in machine mode on kstack
void start(void)
{
	int id = r_mhartid();
	w_tp(id);
	void (*entry)(void) = main;
	entry();
}
