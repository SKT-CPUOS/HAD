#include <stdarg.h>
#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "riscv.h"
#include "defs.h"
#include "proc.h"
#define BACKSPACE 0x100
#define C(x)  ((x)-'@')

struct {
  struct spinlock lock;

  // input
#define INPUT_BUF 128
  char buf[INPUT_BUF];
  uint r;  // Read index
  uint w;  // Write index
  uint e;  // Edit index
} cons;


void consputc(int c)
{
	extern volatile int panicked;
	if (panicked) while (1);
	if (BACKSPACE == c) {
		// if the user typed backspace, overwrite with a space
		uart_putchar('\b');
		uart_putchar(' ');
		uart_putchar('\b');
	}
	else uart_putchar(c);
}

int
consolewrite(int user_src, uint32 src, int n)
{ 
  int i;
  
  acquire(&cons.lock);
  for(i = 0; i < n; i++){
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
      break;
    consputc(c);
  }
  release(&cons.lock);
  
  return n;
}


void consoleintr(int c)
{
	acquire(&cons.lock);
	if (C('P') == c) procdump();
	else if (C('U') == c) {
		struct proc* p = mycpu()->proc;
		if (p != 0) p->killed = 1;	
	}
	else if(c != 0 && cons.e-cons.r < INPUT_BUF){
      	c = (c == '\r') ? '\n' : c;
      	// echo back to the user.
      	consputc(c);
      	// store for consumption by consoleread().
      	cons.buf[cons.e++ % INPUT_BUF] = c;
      	if(c == '\n' || c == C('D') || cons.e == cons.r+INPUT_BUF){
        	// wake up consoleread() if a whole line (or end-of-file)
        	// has arrived.
        	cons.w = cons.e;
        	wakeup(&cons.r);
      	}
    }
  	release(&cons.lock);
}

int
consoleread(int user_dst, uint32 dst, int n)
{
  uint target;
  int c;
  char cbuf;

  target = n;
  acquire(&cons.lock);
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
      if(myproc()->killed){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    }

    c = cons.buf[cons.r++ % INPUT_BUF];

    if(c == C('D')){  // end-of-file
      if(n < target){
        // Save ^D for next time, to make sure
        // caller gets a 0-byte result.
		cons.r--;
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
      break;

    dst++;
    --n;

    if(c == '\n'){
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);

  return target - n;
}

void
consoleinit(void)
{
  initlock(&cons.lock, "cons");
  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read  = consoleread;
  devsw[CONSOLE].write = consolewrite;
}

