#define null 0x00000000
struct buf;
struct context;
struct file;
struct inode;
struct pipe;
struct proc;
struct spinlock;
struct sleeplock;
struct stat;
struct superblock;
struct sharemem;

// bio.c
void            binit(void);
struct buf*     bread(uint, uint);
void            brelse(struct buf*);
void            bwrite(struct buf*);
void            bpin(struct buf*);
void            bunpin(struct buf*);

// console.c
void            consoleinit(void);
void 			consputc(int);
void            consoleintr(int);

// exec.c
int             exec(char*, char**);

// file.c
struct file*    filealloc(void);
void            fileclose(struct file*);
struct file*    filedup(struct file*);
void            fileinit(void);
int             fileread(struct file*, uint32, int n); 
int             filestat(struct file*, uint32 addr);
int             filewrite(struct file*, uint32, int n);

// fs.c
void            fsinit(int);
int             dirlink(struct inode*, char*, uint);
struct inode*   dirlookup(struct inode*, char*, uint*);
struct inode*   ialloc(uint, short);
struct inode*   idup(struct inode*);
void            iinit();
void            ilock(struct inode*);
void            iput(struct inode*);
void            iunlock(struct inode*);
void            iunlockput(struct inode*);
void            iupdate(struct inode*);
int             namecmp(const char*, const char*);
struct inode*   namei(char*);
struct inode*   nameiparent(char*, char*);
int             readi(struct inode*, int, uint32, uint, uint);
void            stati(struct inode*, struct stat*);
int             writei(struct inode*, int, uint32, uint, uint);

// kalloc.c
void* 		    kalloc(void);
void 			kfree(void *);
void 			kinit(void);

// listen_table.S
void            listen_table(int*);

// log.c
void            initlog(int, struct superblock*);
void            log_write(struct buf*);
void            begin_op();
void            end_op();

// pipe.c
int             pipealloc(struct file**, struct file**);
void            pipeclose(struct pipe*, int);
int             piperead(struct pipe*, uint32, int);
int             pipewrite(struct pipe*, uint32, int);


// printf.c
void 			panic(const char*);
void			printf(const char*, ...);

// proc.c
int             allocpid(void);
int cpuid();
struct cpu*		mycpu(void);
struct proc*	myproc(void);
pagetable_t     proc_pagetable(struct proc *);
void            proc_freepagetable(pagetable_t, uint32);
void            procinit(void);
void            sched(void);
void            userinit(void);
void            scheduler(void) __attribute__((noreturn));
void            proc_mapstacks(pagetable_t)__attribute__((optimize("O0")));
void            sched(void);
void            sleep(void*, struct spinlock*);
void            wakeup(void*);
int             either_copyout(int user_dst, uint32 dst, void *src, uint32 len);
int             either_copyin(void *dst, int user_src, uint32 src, uint32 len);
void            exit(int);
int				fork(void);
void			forkret(void);
int             growproc(int);
int             kill(int);
void            yield(void);
void            procdump(void);
void            wakeup1p(void*);

// swtch.S
void            swtch(struct context*, struct context*);

// spinlock.c
void            acquire(struct spinlock*);
int             holding(struct spinlock*);
void            initlock(struct spinlock*, char*);
void            release(struct spinlock*);
void            push_off(void);
void            pop_off(void);
void            seminit(void);

// sleeplock.c
void            acquiresleep(struct sleeplock*);
void            releasesleep(struct sleeplock*);
int             holdingsleep(struct sleeplock*);
void            initsleeplock(struct sleeplock*, char*);

// string.c
int             memcmp(const void*, const void*, int);
void*           memmove(void*, const void*, int);
void*           memset(void*, int, int);
char*           safestrcpy(char*, const char*, int);
int             strlen(const char*);
int             strncmp(const char*, const char*, uint);
char*           strncpy(char*, const char*, int);


// syscall.c
int             argint(int, int*);
int             argstr(int, char*, int);
int             argaddr(int, uint32 *);
int             fetchstr(uint32, char*, int);
int             fetchaddr(uint32, uint32*);
void            syscall();
// kernel_test.c
void 			hexdump(char);
void 			check_memory(uchar*, int);
void 			kalloc_test(void);
void 			kalloc_max_test(void);
void 			kvminit_test(void);
void			intdump(int);
void 			vm_test(void);
void 			read_satp(void);
uchar* 			uvminit_test(pagetable_t, uint32);

// trap.c
extern uint     ticks;
extern struct spinlock tickslock;
void            trapinit(void);
void 			trapinithart(void);
void            usertrapret(void);

// thread.c
int clone(void(*)(void*), uint32*, void*, int);
int join(void);
void exit_thread(void);

// uart.c
void 			uart_puts(const char*);
void 			uart_putchar(const int);
char 			uart_getchar(void);
void 			uartintr(void);

// virtio_disk.c
void            virtio_disk_init(void);
void            virtio_disk_rw(struct buf *, int);
void            virtio_disk_intr();

// sharemem.c
void            sharememinit();
void*           shmgetat(uint, uint);
int             shmrefcount(uint);
int             shmrelease(pde_t*, uint32, uint);
void            shmaddcount(uint);
int             shmkeyused(uint, uint);


// vm.c
void 			kvminit(void);
void 			kvminithart(void);
pagetable_t		kvmmake(void);
void 			kvmmap(pagetable_t, uint32, uint32, uint32, int);
int 			mappages(pagetable_t, uint32, uint32, uint32, int);
pagetable_t     uvmcreate(void);
void            uvmfree(pagetable_t, uint32);
void            uvminit(pagetable_t, uchar *, uint);
void            uvmunmap(pagetable_t, uint32, uint32, int);
uint32          walkaddr(pagetable_t, uint32);
int             copyinstr(pagetable_t, char *, uint32, uint32);
int             copyout(pagetable_t, uint32, char *, uint32);
int             copyin(pagetable_t, char *, uint32, uint32);
int             uvmcopy(pagetable_t, pagetable_t, uint32);
uint32          uvmalloc(pagetable_t, uint32, uint32);
uint32          uvmdealloc(pagetable_t, uint32, uint32);
void            uvmclear(pagetable_t, uint32);

// write_table.S
void            write_table(int*, int);

// number of elements in fixed-size array
#define NELEM(x) (sizeof(x)/sizeof((x)[0]))
