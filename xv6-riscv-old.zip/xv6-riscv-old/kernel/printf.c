#include <stdarg.h>
#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "memlayout.h"
#include "riscv.h"
#include "defs.h"
#include "proc.h"

volatile int panicked = 0;

// lock to avoid interleaving concurrent printf's
static struct {
  struct spinlock lock;
  int locking;
} pr;

static char digits[] = "0123456789abcdef";

static void
printptr(uint32 x)
{
	consputc('0');
	consputc('x');
  	for (int i = 0; i < (sizeof(uint32) * 2); i++, x <<= 4) {
   		 consputc(digits[x >> (sizeof(uint32) * 8 - 4)]);
	}
}

void panic(const char* str)
{
	pr.locking = 0;
	printf("panic: ");
	printf(str);
	printf("\n");
	panicked = 1; 
	while (1);
}

void printf(const char* fmt, ...)
{
	va_list ap;
	int i, c, locking;
	char *s;
	
	locking = pr.locking;
	if (locking) acquire(&pr.lock);
	if (0 == fmt) panic("null fmt");
	va_start(ap, fmt);
	for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    if(c != '%'){
      consputc(c);
      continue;
    }   
    c = fmt[++i] & 0xff;
    if(c == 0)
      break;
    switch(c){
    case 'p':
      printptr(va_arg(ap, uint32));
      break;
    case 's':
	  if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
      break;
    case '%':
      consputc('%');
      break;
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
      consputc(c);
      break;
    }
  }

  if(locking)
    release(&pr.lock);
}

void printfinit(void)
{
	initlock(&pr.lock, "pr");
	pr.locking = 1;
}
