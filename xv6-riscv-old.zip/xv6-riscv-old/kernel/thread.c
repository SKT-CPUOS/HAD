#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

extern struct proc proc[NPROC];
struct spinlock wait_lock;

static void threadfree(struct proc*);
struct proc* allocthread(void)
{
	struct proc* p = 0;
    for (p = proc; p < &proc[NPROC]; p++) {
		acquire(&p->lock);
		if (p->state == UNUSED) goto found;
		else release(&p->lock);
	}
	return 0;

found:
	p->pid = allocpid();
	//p->state = USED;
	
	if ((p->tf = (struct tf *)kalloc()) == 0) {
		threadfree(p);
		release(&p->lock);
		return 0;
	}
	memset(&p->context, 0, sizeof(p->context));
	p->context.ra = (uint32)forkret;
	p->context.sp = p->kstack + PGSIZE;
	return p;
}

int clone(void(*f)(void*), uint32* arg, void* stack, int state) 
{
	int pid = 0;
	struct proc *np = 0;
	struct proc *p = myproc();
	
	if ((np = allocthread()) == 0) return -1;
	
    p->limit -= PGSIZE;
    np->threadframe = p->limit;
	np->pagetable = p->pagetable;
    if (mappages(np->pagetable, np->threadframe, PGSIZE, 
	     (uint32)np->tf, PTE_R | PTE_W) < 0) {
		uvmunmap(np->pagetable, np->threadframe, 1, 0);
		return 0;
	}
	np->sz = p->sz;
	np->tf->a0  = (uint32)arg;
	np->tf->sp  = (uint32)stack + PGSIZE;
    np->tf->epc = (uint32)f;
    np->ustack = (uint32)stack;

	for (int i = 0; i < NOFILE; ++i) {
		if (p->ofile[i]) np->ofile[i] = filedup(p->ofile[i]);
	}
	np->cwd = idup(p->cwd);
	
    safestrcpy(np->name, p->name, sizeof(p->name));

    pid = np->pid;
    
    release(&np->lock);

    acquire(&wait_lock);
    np->parent = 0;
	np->pthread = p;
    release(&wait_lock);
	
	acquire(&np->lock);
	if (1 == state) np->state = RUNNABLE;
	else np->state = SLEEPING;
    release(&np->lock);

	return pid;
}

static void threadfree(struct proc *p)
{
	uvmunmap(p->pagetable, p->threadframe, 1, 1);
	p->tf = 0;
	p->pagetable = 0;
	p->sz = 0;
	p->pid = 0;
    p->parent = 0;
	p->name[0] = 0;
	p->chan = 0;
	p->killed = 0;
	p->xstate = 0;
	p->state = UNUSED;
	p->ustack = 0;
	p->pthread = 0;
	p->threadframe = 0; 
}

int join(void)
{
	int pid = 0;
	int havekids = 0;
	struct proc *np = 0;
	struct proc *p = myproc();
    
	acquire(&wait_lock);
	
    for(;;) {
		havekids = 0;
		for (np = proc; np < &proc[NPROC]; np++) {
			if (np->pthread == p) {
				acquire(&np->lock);
            	havekids = 1;
				if (np->state == ZOMBIE) {
					pid = np->pid;
					threadfree(np);
					release(&np->lock);
					release(&wait_lock);
					return pid;
				}
				release(&np->lock);
			}
		}
		if (!havekids || p->killed) {
			release(&wait_lock);
			return -1;
		}
		sleep(p, &wait_lock);
	}
}

void exit_thread(void)
{
	struct proc *p = myproc();
	
	// close all open files
    for (int fd = 0; fd < NOFILE; fd++) {
		if (p->ofile[fd]) {
			struct file *f = p->ofile[fd];
			fileclose(f);
			p->ofile[fd] = 0;
		}
	}
	begin_op();
	iput(p->cwd);
	end_op();
	p->cwd = 0;

	acquire(&wait_lock);

	wakeup(p->pthread);
	
    acquire(&p->lock);
	p->state = ZOMBIE;

    release(&wait_lock);
	sched();
	panic("zombie exit");
}
