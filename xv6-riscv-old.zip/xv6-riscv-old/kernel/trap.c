#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

#define INTERVAL 1000

extern struct proc proc[NPROC];
struct spinlock tickslock;
uint ticks;

extern char trampoline[], uservec[], userret[];

// in kernelvec.S, calls kerneltrap()
void kernelvec();

extern int devintr();

void timerinit(void)
{
	w_mtimecmp(r_mtime() + INTERVAL);
	w_mstatus(r_mstatus() | MSTATUS_IE);
	w_mie(r_mie() | MIE_MTIE);
}

void
trapinit(void)
{
  initlock(&tickslock, "time");
}

void test(void)
{
	printf("interrupt in user\n");
}

void kerneltrap()
{
	//intr_off();
	int which_dev = 0;
	uint32 mepc = r_mepc();
	uint32 mstatus = r_mstatus();
	uint32 mcause = r_mcause();

	if (intr_get() != 0) panic("kerneltrap: interrupts enabled\n");	
	if (0 == (which_dev = devintr())) {
		uint32* x = (uint32*)r_sp();
		printf("mcause: %p\n", mcause);
		printf("mepc:   %p\n", mepc);
		printf("mtval:  %p\n", r_mtval());
		printf("s0:     %p\n", r_s0());
		printf("ra:     %p\n", r_ra());
		printf("sp:     %p\n", r_sp());
		printf("*sp:    %p\n", *x);
		printf("mstatus:%p\n", r_mstatus());
		printf("satp:   %p\n", r_satp());
		panic("kerneltrap\n");
	}
	if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING) yield();
	w_mepc(mepc);
	w_mstatus(mstatus);
}

void
clockintr()
{
  acquire(&tickslock);
  ticks++;
  //if (0 == ticks % 100) printf("100ticks\n");
  wakeup(&ticks);
  release(&tickslock);
}

void trapinithart(void)
{
	w_mtvec((uint32)kernelvec);	
}

void usertrap(void)
{
	int which_dev = 0;

	//printf("in usertrap\n");
	if (intr_get() != 0) panic("usertrap: interrupts enabled\n");	
  	// send interrupts and exceptions to kerneltrap(),
  	// since we're now in the kernel.
  	w_mtvec((uint32)kernelvec);

  	struct proc *p = myproc();
  
 	// save user program counter.
 	p->tf->epc = r_mepc();
	int mcause = r_mcause();
  
  	if(mcause == 8 || 11 == mcause){ 
    	// system call
		if (p->killed) exit(-1);
		p->tf->epc += 4;
		//intr_on();
	    //printf("usertrap() check point 1\n");	
		syscall();
	}
	else if ((which_dev = devintr()) != 0) {}
	else {
		printf("userttrap()\n");
		printf("pid = %p\n", p->pid);
    	printf("mcause: %p\n", r_mcause());
    	printf("mepc:   %p\n", r_mepc());
    	printf("mtval:  %p\n", r_mtval());
		p->killed = 1;
	}
	if (p->killed) exit(-1);
	if (2 == which_dev) yield();
	usertrapret();
}

void usertrapret(void)
{
	//printf("usertrapret() check point 1\n");
	struct proc *p = myproc();

  	// turn off interrupts, since we're switching
  	// now from kerneltrap() to usertrap().
  	intr_off();

  	// send syscalls, interrupts, and exceptions to trampoline.S
  	w_mtvec(TRAMPOLINE + (uservec - trampoline));

  	// set up trapframe values that uservec will need when
  	// the process next re-enters the kernel.
  	p->tf->kernel_satp = r_satp();         // kernel page table
  	p->tf->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
  	p->tf->kernel_trap = (uint32)usertrap;
  	p->tf->kernel_hartid = r_tp();         // hartid for cpuid()

  	// set up the registers that trampoline.S's sret will use
	// to get to user space.
  
  	// set S Previous Privilege mode to User.
  	unsigned long x = r_mstatus();
	x |= MSTATUS_MIE1;
  	x |= MSTATUS_PRV1; // clear SPP to 0 for user mode
  	//x |= MSTATUS_IE; // enable interrupts in user mode
  	w_mstatus(x);

  	// set S Exception Program Counter to the saved user pc.
 	w_mepc(p->tf->epc);

  	// tell trampoline.S the user page table to switch to.
  	uint32 satp = MAKE_SATP(p->pagetable);

  	// jump to trampoline.S at the top of memory, which 
  	// switches to the user page table, restores user registers,
  	// and switches to user mode with sret.
 	uint32 fn = TRAMPOLINE + (userret - trampoline);
	//printf("usertrapret() check point 2\n");
	if (p->pthread) {
     	((void (*)(uint32,uint32))fn)(p->threadframe, satp);
  	}
 	else {
        ((void (*)(uint32,uint32))fn)(TRAPFRAME, satp);
  	}

  	//((void (*)(uint32,uint32))fn)(TRAPFRAME, satp);
}

int devintr()
{
	uint32 mcause = r_mcause();
	if (0x12 == mcause) {
		//printf("in dataflow\n");
		int dfcpid = r_dfcpid();
		struct proc* p = proc;
		for (; p < &proc[NPROC]; ++p) {
			acquire(&p->lock);
			if (p->pid == dfcpid) {
				p->state = RUNNABLE;
			}
			release(&p->lock);
		}
		//printf("%p\n", mcause);
		return 3;
	}
	else if (0x80000001 == mcause) {
		//printf("timer epc:%p mstatus:%p sp:%p\n", r_mepc(), r_mstatus(), r_sp());
		//printf("mstatus:%p\n", r_mstatus());
		//printf("satp:   %p\n", r_satp());
		//printf("sp:     %p\n", r_sp());
		//printf("dfcpid:     %p\n",  r_mhartid());
		//printf("mhartid:     %p\n", r_dfcpid());
		if (0 == cpuid()) clockintr();
		w_mtimecmp(r_mtime() + INTERVAL);
		return 2;
	}
	else if (0x10 == mcause) {
		//intr_on();
		//printf("uartintr\n");
		uartintr();		
		return 1;
	}
	return 0;
}
