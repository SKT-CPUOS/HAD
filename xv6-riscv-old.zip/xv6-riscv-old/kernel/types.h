typedef unsigned char  uchar;
typedef unsigned short ushort;
typedef unsigned int   uint;

typedef unsigned char  uint8;
typedef unsigned short uint16;
typedef unsigned int   uint32;
typedef uint32 pde_t;
typedef uint32 pte_t;
typedef uint32 *pagetable_t;
