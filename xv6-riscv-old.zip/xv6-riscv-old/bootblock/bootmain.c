#include "types.h"
#include "elf.h"
#include "uart.c"

void* memset(void *dst, int c, int n)
{
	char *cdst = (char*)dst;
	for (int i = 0; i < n; ++i) cdst[i] = c;
	return dst;	
} 

void* memmove(void *vdst, const void *vsrc, int n)
{
	char *dst = (char*)vdst;
	const char *src = (const char*)vsrc;
	if (src > dst) {
		while (n-- > 0)  *dst++ = *src++;
	}
	else {
		dst += n;
		src += n;
		while (n-- > 0) *--dst = *--src;
	}
	return vdst;
}

void copyfile(struct elfhdr *elf)
{
	struct proghdr *ph  = (struct proghdr*)((uchar*)elf + (elf -> phoff));
	struct proghdr *eph = (struct proghdr*)(ph  + elf -> phnum);
	for (; ph < eph; ++ph) {
		uchar *dst = (uchar*)(ph -> paddr);
		uchar *pa  = (uchar*)elf;
		uchar *src = pa + ph -> off;
		memmove(dst, src, ph -> filesz);
		if (ph -> memsz > ph -> filesz) {
			memset(dst + ph -> filesz, 0, ph->memsz - ph->filesz); 
		}
	}
}

void load_elf(uchar* pa, int kernel_size)
{
    uchar* epa = pa + kernel_size;
    for (; pa < epa; ++pa) *pa = uart_getchar();
}

int get_kernel_size(void)
{
	#define BUFSIZE 10
    char is_equal = '0';
    char buf[BUFSIZE + 2] = {0}; buf[BUFSIZE] = '\n';
    while ('0' == is_equal) {
        for (int k = 0; k < BUFSIZE; ++k) buf[k] = 0;
        uart_puts("What is the kernel size?\n");
        for (int k = 0; k < BUFSIZE; ++k) buf[k] = uart_getchar();
        uart_puts(buf);
        uart_puts("Does the kernel size correct? Error: 0 Correct: 1\n");
        is_equal = uart_getchar();
    }
    int size = 0;
    for (int k = 0; k < BUFSIZE; ++k) {
        int tp = size;
        size = (tp << 1) + (tp << 3);
        size += buf[k] - '0';
    }
    return size;
}

void hexdump(char x)
{   
	static const char hex[] = "0123456789abcdef";
    uart_puts("0x"); 
    char high = (x & 0xf0) >> 4;
    char low  = (x & 0x0f);
    uart_putchar(hex[high]);
    uart_putchar(hex[low]);
}

void intdump(int val)
{
    static const char hex[] = "0123456789abcdef";
    char *p = (char*)&val;
    uart_puts("0x");
    for (int k = 3; k >= 0; --k) {
        char x = *(p + k);
        char high = (x & 0xf0) >> 4;
        char low  = (x & 0x0f);
        uart_putchar(hex[high]);
        uart_putchar(hex[low]);
    }
    uart_puts("\n");
}


void check_file(uchar* pa, int kernel_size)
{
    for (int k = 1; k <= kernel_size; ++k) {
        char ch = *pa;
        hexdump(ch);
        int x = k & (~0xfffffff8);
        if (x) uart_putchar(' ');
        else uart_putchar('\n');
        ++pa;
    }
}

void check(struct elfhdr *elf)
{
	struct proghdr *ph  = (struct proghdr*)((uchar*)elf + (elf -> phoff));
	struct proghdr *eph = (struct proghdr*)(ph  + elf -> phnum);
	for (; ph < eph; ++ph) {
		uchar *pa = (uchar*)(ph -> paddr);
		int file_size = ph -> filesz;
		check_file(pa, file_size);
		if (ph -> memsz > ph -> filesz) {
			check_file(pa + ph -> filesz, ph->memsz - ph->filesz); 
		}
		uart_puts("\n**********\n");
	}
}

void test_mem(int* start, int size)
{
	int *p = start;
	for (int k = 0; k < size; ++k) *(p + k) = k;
    int *q = start;
    for (int k = 0; k < size; ++k) intdump(*(q + k));
}
void BootByUart(void)
{
	int kernel_size = get_kernel_size();
	uart_puts("Loading the ELF!\n");
	struct elfhdr* elf  = (struct elfhdr*)0x88000000;
	load_elf((uchar*)elf, kernel_size);
	if (elf -> magic != ELF_MAGIC) {
		while (1) uart_puts("The file is not ELF type!\n");
	}
	copyfile(elf);	
	uart_puts("Do you want to check the kernel file? Yes: 0 No: 1\n");
	char check_file = uart_getchar();
	if ('0' == check_file) check(elf);
	uart_puts("The kernel load address is ");
	void (*entry)(void) = (void(*)(void))(elf -> entry);
	intdump((int)entry);
	uart_puts("start to leave the bootblock\n");
	entry();
	uart_puts("bootmain.c: return from the kernel error!!!\n");
}

void BootFromFlash(void)
{
	struct elfhdr* elf  = (struct elfhdr*)0x40000000;
	uart_puts("The kernel load address is ");
	void (*entry)(void) = (void(*)(void))(elf -> entry);
	intdump((int)entry);
	uart_puts("start to leave the bootblock\n");
	entry();
	uart_puts("bootmain.c: return from the kernel error!!!\n");
}

void InstallOsToFlash(void)
{
	int kernel_size = get_kernel_size();
	uart_puts("Loading the ELF!\n");
	struct elfhdr* elf  = (struct elfhdr*)0x40000000;
	load_elf((uchar*)elf, kernel_size);
	if (elf -> magic != ELF_MAGIC) {
		while (1) uart_puts("The file is not ELF type!\n");
	}
	copyfile(elf);	
	uart_puts("Do you want to check the kernel file? Yes: 0 No: 1\n");
	char check_file = uart_getchar();
	if ('0' == check_file) check(elf);
}

void main(void)
{
	while (1)
	{	
		uart_puts("RISC-V SKT BIOS System:The CPU0 is started\n");
		uart_puts("Select OS Boot method:\n");
		uart_puts("0:Boot from flash\n");
		uart_puts("1:Boot by UART transfer kernel.\n");
		uart_puts("2:Install OS to flash\n");
		char choice = uart_getchar();
		if (choice == '0')
			BootFromFlash();
		if (choice == '1')
			BootByUart();
		if (choice == '2')
			InstallOsToFlash();
	}
	

}
