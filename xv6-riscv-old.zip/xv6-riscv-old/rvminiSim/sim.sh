#!/bin/bash
basedir=~/xv6-riscv-old/rvminiSim
verilator --cc --exe Tile.v -CFLAGS "-std=c++11 -Wall -Wno-unused-variable -include ${basedir}/obj_dir/VTile.h" ${basedir}/mm.cc ${basedir}/top.cc
make -j -C ./obj_dir/ -f VTile.mk VTile  

