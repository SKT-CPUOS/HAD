import sys
import re

def extraData(srcFile,destFile):
    with open(srcFile,'r') as ihexFile:
        lines = ihexFile.readlines()
        with open(destFile,"w") as hexFile:
            for line in lines:
                match = re.match(":10[\d\D]*\n",line)
                if(match != None):
                    hexFile.write(line[-35:-3].lower() + "\n")

if __name__ == '__main__':
    if(len(sys.argv) != 3):
        print("usage : ihex2Hex <srcFile> <destFile>")
    else:
        extraData(sys.argv[1],sys.argv[2])
